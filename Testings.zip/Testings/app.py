import sys
import os
from PyQt5.QtCore import Qt, QTimer, QRectF
from PyQt5.QtGui import QPixmap, QIcon, QPainterPath, QRegion
from PyQt5.QtWidgets import QApplication, QLabel, QWidget, QDesktopWidget


class RemWindow(QWidget):
    def __init__(self):
        super().__init__()

        # Frameless + always on top + tool window
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.label = QLabel(self)

        # Define sizes
        self.full_size = 200
        self.small_size = 80

        # Animation state
        self.animations = {}
        self.current_anim = "Blink"
        self.current_frame = 0

        self.load_animations("animations")
        self.set_icon_size(self.small_size)

        # Screen geometry
        self.screen_geo = QDesktopWidget().availableGeometry()
        self.y_pos = self.screen_geo.height() // 2 - self.height() // 2
        self.move(self.screen_geo.width() - self.width(), self.y_pos)

        # Dragging
        self.offset = None
        self.expanded = False
        self.is_closing = False

        # Idle shrink timer
        self.idle_timer = QTimer(self)
        self.idle_timer.timeout.connect(self.auto_shrink)
        self.idle_timer.setInterval(3000)
        self.idle_timer.start()

        # Animation timer
        self.anim_timer = QTimer(self)
        self.anim_timer.timeout.connect(self.next_frame)
        self.anim_timer.start(100)  # 200ms per frame (~5 fps)

    def load_animations(self, base_path):
        """Load frames from animations/<name> folders"""
        for anim in os.listdir(base_path):
            anim_path = os.path.join(base_path, anim)
            if os.path.isdir(anim_path):
                frames = []
                for fname in sorted(os.listdir(anim_path)):
                    if fname.lower().endswith(".png"):
                        frames.append(QPixmap(os.path.join(anim_path, fname)))
                if frames:
                    self.animations[anim] = frames

    def set_animation(self, anim_name):
        """Switch animation"""
        if anim_name in self.animations:
            self.current_anim = anim_name
            self.current_frame = 0
            self.set_icon_size(self.full_size if self.expanded else self.small_size)

    def set_icon_size(self, size):
        """Resize current frame and window with round mask"""
        if self.current_anim not in self.animations:
            return
        frame = self.animations[self.current_anim][self.current_frame]
        scaled = frame.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.label.setPixmap(scaled)
        self.resize(scaled.size())

        # Circular mask
        path = QPainterPath()
        path.addEllipse(QRectF(0, 0, size, size))
        region = QRegion(path.toFillPolygon().toPolygon())
        self.setMask(region)

    def next_frame(self):
        """Advance animation frame"""
        if self.current_anim in self.animations:
            self.current_frame = (self.current_frame + 1) % len(self.animations[self.current_anim])
            size = self.full_size if self.expanded else self.small_size
            self.set_icon_size(size)

    # --- Mouse events ---
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.offset = event.globalPos() - self.frameGeometry().topLeft()
            self.idle_timer.stop()
            self.set_animation("Drag")  # start Drag animation

    def mouseMoveEvent(self, event):
        if self.offset is not None and event.buttons() == Qt.LeftButton:
            new_pos = event.globalPos() - self.offset
            self.move(new_pos)

            # If near bottom, switch to Dead
            bottom_threshold = self.screen_geo.height() - 100
            if self.y() >= bottom_threshold:
                if not self.is_closing:
                    self.set_animation("Dead")
                    self.is_closing = True
            else:
                if self.is_closing:
                    self.set_animation("Drag")
                    self.is_closing = False

    def mouseReleaseEvent(self, event):
        self.offset = None
        bottom_threshold = self.screen_geo.height() - 100
        if self.y() >= bottom_threshold:
            QApplication.quit()
        else:
            self.idle_timer.start()
            self.set_animation("Blink")  # back to blinking when idle

    def mouseDoubleClickEvent(self, event):
        if self.expanded:
            self.shrink()
        else:
            self.expand()

    # --- Expand / Shrink ---
    def expand(self):
        self.set_animation("Blink")
        self.set_icon_size(self.full_size)
        self.expanded = True

    def shrink(self):
        self.set_animation("Blink")
        self.set_icon_size(self.small_size)
        self.expanded = False

    def auto_shrink(self):
        if not self.expanded:
            self.shrink()
            self.set_animation("Rest")  # Rest animation when docked

            current_y = self.y()
            x = self.screen_geo.width() - (self.width() // 2)
            self.move(x, current_y)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("img.png"))

    rem = RemWindow()
    rem.show()

    sys.exit(app.exec_())
