import sys
import os
import threading
import json
from PyQt5.QtCore import Qt, QTimer, QRectF, pyqtSignal
from PyQt5.QtGui import QPixmap, QIcon, QPainterPath, QRegion
from PyQt5.QtWidgets import QApplication, QLabel, QWidget, QDesktopWidget

def generate_animation_registry(base_path="animations", output_file="animations/animations.json"):
    registry = {"State": {}, "Emotions": {}}

    for category in ["State", "Emotions"]:
        cat_path = os.path.join(base_path, category)

        if not os.path.exists(cat_path):
            continue

        for anim in os.listdir(cat_path):
            anim_path = os.path.join(cat_path, anim)

            if os.path.isdir(anim_path):
                frames = [f for f in os.listdir(anim_path) if f.lower().endswith(".png")]
                frame_count = len(frames)

                fps = 8
                config_path = os.path.join(anim_path, "config.json")

                if os.path.exists(config_path):
                    try:
                        with open(config_path) as f:
                            data = json.load(f)
                            fps = data.get("fps", 8)
                    except:
                        pass

                registry[category][anim] = {
                    "frames": frame_count,
                    "fps": fps
                }

    with open(output_file, "w") as f:
        json.dump(registry, f, indent=4)

    print("✅ Registry generated")

class RemWindow(QWidget):
    # ✅ SIGNAL (thread-safe communication)
    update_signal = pyqtSignal(str, str)  # state, emotion

    def __init__(self):
        super().__init__()

        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.label = QLabel(self)

        self.small_size = 100

        self.animations = {}
        self.anim_fps = {}

        self.current_anim = "Normal"
        self.current_frame = 0

        self.state = "Normal"
        self.emotion = None

        self.offset = None  # dragging

        self.load_animations("animations")
        self.set_icon_size(self.small_size)

        self.screen_geo = QDesktopWidget().availableGeometry()
        self.move(self.screen_geo.width() - self.width(),
                  self.screen_geo.height() // 2)

        self.anim_timer = QTimer(self)
        self.anim_timer.timeout.connect(self.next_frame)

        self.set_animation("Normal")

        # ✅ CONNECT SIGNAL
        self.update_signal.connect(self.handle_update)

        # Start input thread
        threading.Thread(target=self.input_loop, daemon=True).start()


    # 🔥 LOAD ANIMATIONS + FPS
    def load_animations(self, base_path):
        for category in ["State", "Emotions"]:
            cat_path = os.path.join(base_path, category)

            if not os.path.exists(cat_path):
                continue

            for anim in os.listdir(cat_path):
                anim_path = os.path.join(cat_path, anim)

                if os.path.isdir(anim_path):
                    frames = []

                    for fname in sorted(os.listdir(anim_path)):
                        if fname.lower().endswith(".png"):
                            frames.append(QPixmap(os.path.join(anim_path, fname)))

                    if frames:
                        self.animations[anim] = frames

                        # Load config.json
                        config_path = os.path.join(anim_path, "config.json")
                        fps = 8  # default FPS

                        if os.path.exists(config_path):
                            try:
                                with open(config_path) as f:
                                    data = json.load(f)
                                    fps = data.get("fps", 8)
                            except:
                                pass

                        self.anim_fps[anim] = fps

        print("Loaded animations:", list(self.animations.keys()))

    # 🎯 HANDLE UPDATE (MAIN THREAD SAFE)
    def handle_update(self, state, emotion):
        if state:
            self.state = state
            self.emotion = None  # reset emotion when state changes
            print("State:", state)

        elif emotion:
            self.emotion = emotion
            print("Emotion:", emotion)

        self.update_animation()

    # 🎯 PRIORITY SYSTEM
    def update_animation(self):
        if self.emotion:
            self.set_animation(self.emotion)
        elif self.state:
            self.set_animation(self.state)
        else:
            self.set_animation("Blink")

    def set_animation(self, anim_name):
        if anim_name in self.animations:
            self.current_anim = anim_name
            self.current_frame = 0

            fps = self.anim_fps.get(anim_name, 8)
            interval = int(1000 / fps)

            self.anim_timer.start(interval)

    def set_icon_size(self, size):
        if self.current_anim not in self.animations:
            return

        frame = self.animations[self.current_anim][self.current_frame]
        scaled = frame.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)

        self.label.setPixmap(scaled)
        self.resize(scaled.size())

        path = QPainterPath()
        path.addEllipse(QRectF(0, 0, size, size))
        self.setMask(QRegion(path.toFillPolygon().toPolygon()))

    def next_frame(self):
        if self.current_anim in self.animations:
            self.current_frame = (self.current_frame + 1) % len(self.animations[self.current_anim])
            self.set_icon_size(self.small_size)

    # 🖱️ DRAGGING
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.offset = event.globalPos() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, event):
        if self.offset and event.buttons() == Qt.LeftButton:
            self.move(event.globalPos() - self.offset)

    def mouseReleaseEvent(self, event):
        self.offset = None

    # 🎤 INPUT LOOP (THREAD → SIGNAL)
    def input_loop(self):
        while True:
            try:
                user_input = input("\nEnter: ").strip()

                if user_input.lower().startswith("state:"):
                    state = user_input.split(":")[1].strip()
                    self.update_signal.emit(state, "")

                elif user_input.lower().startswith("emotion:"):
                    emotion = user_input.split(":")[1].strip()
                    self.update_signal.emit("", emotion)

            except Exception as e:
                print("Error:", e)


if __name__ == "__main__":
    generate_animation_registry()
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("img.png"))

    rem = RemWindow()
    rem.show()

    sys.exit(app.exec_())