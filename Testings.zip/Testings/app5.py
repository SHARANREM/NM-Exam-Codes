import whisper
import sounddevice as sd
import numpy as np
import keyboard
import time
import psutil
import os
from groq import Groq

# 🔐 Add your Groq API key here
client = Groq(api_key="")

# 🔁 Model configs
WHISPER_MODEL = "small"
GROQ_MODEL = "llama-3.3-70b-versatile" # fast + powerful

print(f"Loading Whisper model: {WHISPER_MODEL}...")
model = whisper.load_model(WHISPER_MODEL)

process = psutil.Process(os.getpid())

samplerate = 16000

# 🧠 Conversation memory
chat_history = [
    {"role": "system", "content": "You are a helpful voice assistant. Keep responses short and natural."}
]

print("Hold LEFT CTRL to speak... (Press ESC to exit)")

while True:
    if keyboard.is_pressed("esc"):
        print("Exiting...")
        break

    if keyboard.is_pressed("ctrl"):
        print("🎤 Recording...")

        recording = []
        start_record_time = time.time()

        # 🎤 Record while CTRL is held
        with sd.InputStream(samplerate=samplerate, channels=1, dtype='int16') as stream:
            while keyboard.is_pressed("ctrl"):
                data, _ = stream.read(1024)
                recording.append(data)

        end_record_time = time.time()

        print("🧠 Transcribing...")

        # Combine audio
        audio_data = np.concatenate(recording, axis=0)

        # Convert int16 → float32
        audio_data = audio_data.astype(np.float32) / 32768.0
        audio_data = audio_data.flatten()

        # ⏱️ Whisper timing
        start_time = time.time()
        result = model.transcribe(audio_data, fp16=False)
        end_time = time.time()

        user_text = result["text"].strip()

        if not user_text:
            print("⚠️ No speech detected")
            continue

        print("📝 You said:", user_text)

        # 🧠 Add user input to chat
        chat_history.append({"role": "user", "content": user_text})

        print("🤖 Thinking...")

        # 🤖 Groq response
        response = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=chat_history
        )

        bot_reply = response.choices[0].message.content

        # Save assistant reply
        chat_history.append({"role": "assistant", "content": bot_reply})

        # 📊 Metrics
        audio_duration = end_record_time - start_record_time
        processing_time = end_time - start_time
        ram_usage = process.memory_info().rss / (1024 * 1024)
        speed_ratio = processing_time / audio_duration if audio_duration > 0 else 0

        # 🧾 Output
        print("🤖 Assistant:", bot_reply)
        print("📊 --- Metrics ---")
        print(f"🎙️ Audio Length     : {audio_duration:.2f} sec")
        print(f"⏱️ STT Time         : {processing_time:.2f} sec")
        print(f"⚡ Speed Ratio      : {speed_ratio:.2f}x")
        print(f"💾 RAM Usage        : {ram_usage:.2f} MB")
        print("-------------------\n")