// src/firebase/firebaseConfig.js

import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import firebaseConfig from "../../firebase-applet-config.json";

// ✅ Fix duplicate app issue
const app = !getApps().length
  ? initializeApp(firebaseConfig)
  : getApp();

// ✅ Services
export const auth = getAuth(app);
export const db = getFirestore(app);

export default app;