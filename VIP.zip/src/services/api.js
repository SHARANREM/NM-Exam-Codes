import { db, auth } from "../firebase/firebaseConfig";
import { 
  collection, 
  addDoc, 
  getDocs, 
  getDoc, 
  doc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  serverTimestamp,
  setDoc,
  onSnapshot,
  getDocFromServer
} from "firebase/firestore";

const OperationType = {
  CREATE: 'create',
  UPDATE: 'update',
  DELETE: 'delete',
  LIST: 'list',
  GET: 'get',
  WRITE: 'write',
};

function handleFirestoreError(error, operationType, path) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test connection
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if(error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration. ");
    }
  }
}
testConnection();

export const createUserProfile = async (uid, data) => {
  const path = `users/${uid}`;
  try {
    await setDoc(doc(db, "users", uid), {
      ...data,
      uid,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
};

export const getUserProfile = async (uid) => {
  const path = `users/${uid}`;
  try {
    const userDoc = await getDoc(doc(db, "users", uid));
    return userDoc.exists() ? userDoc.data() : null;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
};

export const addCourse = async (data) => {
  const path = 'courses';
  try {
    await addDoc(collection(db, path), {
      ...data,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
};

export const getCourses = (callback) => {
  const path = 'courses';
  return onSnapshot(collection(db, path), (snapshot) => {
    const courses = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(courses);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
  });
};

export const updateCourse = async (id, data) => {
  const path = `courses/${id}`;
  try {
    await updateDoc(doc(db, "courses", id), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
};

export const deleteCourse = async (id) => {
  const path = `courses/${id}`;
  try {
    await deleteDoc(doc(db, "courses", id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
};

// Similar for internships and competitions
export const addInternship = async (data) => {
  const path = 'internships';
  try {
    await addDoc(collection(db, path), {
      ...data,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
};

export const getInternships = (callback) => {
  const path = 'internships';
  return onSnapshot(collection(db, path), (snapshot) => {
    const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(items);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
  });
};

export const updateInternship = async (id, data) => {
  const path = `internships/${id}`;
  try {
    await updateDoc(doc(db, "internships", id), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
};

export const deleteInternship = async (id) => {
  const path = `internships/${id}`;
  try {
    await deleteDoc(doc(db, "internships", id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
};

export const addCompetition = async (data) => {
  const path = 'competitions';
  try {
    await addDoc(collection(db, path), {
      ...data,
      createdAt: new Date().toISOString()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
};

export const getCompetitions = (callback) => {
  const path = 'competitions';
  return onSnapshot(collection(db, path), (snapshot) => {
    const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(items);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
  });
};

export const updateCompetition = async (id, data) => {
  const path = `competitions/${id}`;
  try {
    await updateDoc(doc(db, "competitions", id), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
};

export const deleteCompetition = async (id) => {
  const path = `competitions/${id}`;
  try {
    await deleteDoc(doc(db, "competitions", id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
};

export const registerForItem = async (userId, itemId, type) => {
  const path = 'registrations';
  try {
    await addDoc(collection(db, path), {
      userId,
      itemId,
      type,
      registeredAt: new Date().toISOString()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
};

export const getUserRegistrations = (userId, callback) => {
  const path = 'registrations';
  const q = query(collection(db, path), where("userId", "==", userId));
  return onSnapshot(q, (snapshot) => {
    const items = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(items);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
  });
};
