import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { getUserRegistrations, getCourses, getInternships, getCompetitions } from "../services/api";
import { motion } from "motion/react";
import { User, BookOpen, Briefcase, Award, Clock, ExternalLink, Bell } from "lucide-react";
import MessageModal from "../components/MessageModal";

const Dashboard = () => {
  const { userData } = useAuth();
  const [registrations, setRegistrations] = useState([]);
  const [courses, setCourses] = useState([]);
  const [internships, setInternships] = useState([]);
  const [competitions, setCompetitions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedItem, setSelectedItem] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openAnnouncements = (item, type) => {
    setSelectedItem({ ...item, type });
    setIsModalOpen(true);
  };

  useEffect(() => {
    if (userData?.uid) {
      const unsubReg = getUserRegistrations(userData.uid, setRegistrations);
      const unsubCourses = getCourses(setCourses);
      const unsubInternships = getInternships(setInternships);
      const unsubCompetitions = getCompetitions(setCompetitions);
      setLoading(false);
      return () => {
        unsubReg();
        unsubCourses();
        unsubInternships();
        unsubCompetitions();
      };
    }
  }, [userData]);

  const getRegisteredItem = (reg) => {
    if (reg.type === "course") return courses.find(c => c.id === reg.itemId);
    if (reg.type === "internship") return internships.find(i => i.id === reg.itemId);
    if (reg.type === "competition") return competitions.find(c => c.id === reg.itemId);
    return null;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Sidebar */}
        <div className="lg:col-span-1 space-y-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="card-premium p-8 text-center"
          >
            <div className="w-24 h-24 bg-royal-blue/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <User size={48} className="text-royal-blue" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{userData?.name}</h2>
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">{userData?.email}</p>
            <div className="space-y-3 text-left">
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Age:</span>
                <span className="font-semibold">{userData?.age}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Gender:</span>
                <span className="font-semibold">{userData?.gender}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-500">Mobile:</span>
                <span className="font-semibold">{userData?.mobile}</span>
              </div>
            </div>
            <div className="mt-8 pt-8 border-t border-gray-100 dark:border-gray-800 flex flex-col space-y-3">
              {userData?.resumeUrl && (
                <a href={userData.resumeUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-royal-blue hover:underline flex items-center justify-center space-x-2">
                  <ExternalLink size={14} /> <span>View Resume</span>
                </a>
              )}
              {userData?.linkedinUrl && (
                <a href={userData.linkedinUrl} target="_blank" rel="noopener noreferrer" className="text-sm text-royal-blue hover:underline flex items-center justify-center space-x-2">
                  <ExternalLink size={14} /> <span>LinkedIn Profile</span>
                </a>
              )}
            </div>
          </motion.div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          <div className="flex justify-between items-center">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white">My Registrations</h3>
            <span className="px-3 py-1 bg-royal-blue/10 text-royal-blue rounded-full text-xs font-bold">
              {registrations.length} Items
            </span>
          </div>

          {registrations.length === 0 ? (
            <div className="card-premium p-12 text-center space-y-4">
              <div className="w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto">
                <Clock size={32} className="text-gray-400" />
              </div>
              <h4 className="text-lg font-bold text-gray-900 dark:text-white">No registrations yet</h4>
              <p className="text-gray-500 dark:text-gray-400 max-w-xs mx-auto">
                Explore our courses, internships, and competitions to get started.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {registrations.map((reg) => {
                const item = getRegisteredItem(reg);
                if (!item) return null;
                return (
                  <motion.div
                    key={reg.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="card-premium p-6 flex items-center space-x-6"
                  >
                    <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0">
                      <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="flex-grow">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                          reg.type === 'course' ? 'bg-blue-100 text-blue-600' :
                          reg.type === 'internship' ? 'bg-green-100 text-green-600' :
                          'bg-purple-100 text-purple-600'
                        }`}>
                          {reg.type}
                        </span>
                        <span className="text-xs text-gray-400">
                          {new Date(reg.registeredAt).toLocaleDateString()}
                        </span>
                      </div>
                      <h4 className="font-bold text-gray-900 dark:text-white">{item.title}</h4>
                    </div>
                    <div className="shrink-0 flex items-center space-x-2">
                      <button 
                        onClick={() => openAnnouncements(item, reg.type)}
                        className="p-2 rounded-full bg-amber-100 text-amber-600 hover:bg-amber-600 hover:text-white transition-all"
                        title="View Announcements"
                      >
                        <Bell size={20} />
                      </button>
                      {item.googleFormLink || item.applyLink || item.registrationLink ? (
                        <a 
                          href={item.googleFormLink || item.applyLink || item.registrationLink} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-2 rounded-full bg-royal-blue/10 text-royal-blue hover:bg-royal-blue hover:text-white transition-all"
                        >
                          <ExternalLink size={20} />
                        </a>
                      ) : null}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {selectedItem && (
        <MessageModal 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)} 
          itemId={selectedItem.id} 
          itemTitle={selectedItem.title} 
          type={selectedItem.type} 
        />
      )}
    </div>
  );
};

export default Dashboard;
