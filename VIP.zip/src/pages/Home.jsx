import React, { useEffect, useState } from "react";
import { motion } from "motion/react";
import { 
  ArrowRight, 
  CheckCircle2, 
  Users, 
  BookOpen, 
  Award, 
  Briefcase, 
  Star, 
  ChevronRight,
  Code,
  Database,
  Cpu,
  Shield,
  Cloud,
  Layers,
  Bot,
  Terminal
} from "lucide-react";
import { Link } from "react-router-dom";

const Home = () => {
  const [stats, setStats] = useState({ students: 0, courses: 0, placements: 0, projects: 0 });

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => ({
        students: Math.min(prev.students + 150, 5000),
        courses: Math.min(prev.courses + 2, 50),
        placements: Math.min(prev.placements + 30, 1200),
        projects: Math.min(prev.projects + 10, 300)
      }));
    }, 50);
    return () => clearInterval(interval);
  }, []);

  const courses = [
    { title: "AI & ML", icon: <Bot className="text-royal-blue" />, desc: "Master neural networks and deep learning.", duration: "6 Months" },
    { title: "Data Science", icon: <Database className="text-royal-blue" />, desc: "Analyze complex data for business insights.", duration: "5 Months" },
    { title: "Full Stack", icon: <Code className="text-royal-blue" />, desc: "Build modern web apps from scratch.", duration: "6 Months" },
    { title: "Python", icon: <Terminal className="text-royal-blue" />, desc: "Learn the world's most popular language.", duration: "3 Months" },
    { title: "Java", icon: <Layers className="text-royal-blue" />, desc: "Enterprise-level application development.", duration: "4 Months" },
    { title: "Cybersecurity", icon: <Shield className="text-royal-blue" />, desc: "Protect systems from digital threats.", duration: "4 Months" },
    { title: "Cloud", icon: <Cloud className="text-royal-blue" />, desc: "Deploy and scale global infrastructure.", duration: "5 Months" },
    { title: "AutoCAD & Robotics", icon: <Cpu className="text-royal-blue" />, desc: "Design and build future machines.", duration: "6 Months" },
  ];

  return (
    <div className="overflow-hidden">
      {/* 3. Hero Section */}
      <section className="relative min-h-[90vh] flex items-center pt-20 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 z-0 opacity-10 dark:opacity-20 pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_50%_50%,#4169E1_0%,transparent_50%)]"></div>
        </div>

        <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-royal-blue/10 text-royal-blue text-sm font-semibold">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-royal-blue opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-royal-blue"></span>
              </span>
              <span>Admissions Open for 2026</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-extrabold text-gray-900 dark:text-white leading-tight">
              Build Skills. <br />
              <span className="text-royal-blue">Build Career.</span> <br />
              Build Future.
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-xl leading-relaxed">
              Join VIP Academy to transform your potential into professional excellence. Industry-leading mentors, hands-on projects, and 100% placement support.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/courses" className="btn-primary flex items-center justify-center space-x-2">
                <span>Explore Courses</span>
                <ArrowRight size={20} />
              </Link>
              <Link to="/signup" className="btn-secondary flex items-center justify-center">
                Apply Now
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-8 border-white dark:border-gray-800">
              <img 
                src="https://picsum.photos/seed/academy/800/600" 
                alt="Academy Hero" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
            </div>
            {/* Floating Card */}
            <div className="absolute -bottom-6 -left-6 bg-white dark:bg-gray-900 p-6 rounded-2xl shadow-xl border border-gray-100 dark:border-gray-800 hidden md:block">
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-gold/10 rounded-xl">
                  <Star className="text-gold" fill="currentColor" />
                </div>
                <div>
                  <p className="text-sm font-bold text-gray-900 dark:text-white">4.9/5 Rating</p>
                  <p className="text-xs text-gray-500">From 2000+ Alumni</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 4. About Snapshot */}
      <section className="py-24 bg-white dark:bg-gray-950 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <img 
                src="https://picsum.photos/seed/about/600/500" 
                alt="About VIP Academy" 
                className="rounded-3xl shadow-xl"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-royal-blue/10 rounded-full -z-10 animate-pulse"></div>
            </div>
            <div className="space-y-6">
              <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm">About VIP Academy</h2>
              <h3 className="text-4xl font-bold text-gray-900 dark:text-white leading-tight">
                Your Gateway to Professional Excellence and Innovation
              </h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                VIP Academy is more than just an educational institution; it's a launchpad for your dreams. We bridge the gap between academic learning and industry requirements with our cutting-edge curriculum and expert guidance.
              </p>
              <ul className="space-y-4">
                {[
                  "Industry-aligned curriculum updated regularly",
                  "Hands-on experience with live projects",
                  "Mentorship from top industry professionals",
                  "State-of-the-art infrastructure and labs"
                ].map((item, i) => (
                  <li key={i} className="flex items-center space-x-3 text-gray-700 dark:text-gray-300">
                    <CheckCircle2 className="text-royal-blue shrink-0" size={20} />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <Link to="/about" className="inline-flex items-center text-royal-blue font-bold hover:underline">
                Learn More About Our Journey <ChevronRight size={20} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Popular Courses */}
      <section className="py-24 bg-bg-light dark:bg-bg-dark px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center mb-16">
          <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm mb-4">Our Programs</h2>
          <h3 className="text-4xl font-bold text-gray-900 dark:text-white">Popular Courses</h3>
        </div>
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {courses.map((course, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -10 }}
              className="card-premium p-8 flex flex-col items-center text-center space-y-4"
            >
              <div className="p-4 bg-royal-blue/10 rounded-2xl mb-2">
                {React.cloneElement(course.icon, { size: 32 })}
              </div>
              <h4 className="text-xl font-bold text-gray-900 dark:text-white">{course.title}</h4>
              <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">
                {course.desc}
              </p>
              <div className="pt-4 border-t border-gray-100 dark:border-gray-800 w-full flex justify-between items-center text-xs font-semibold text-gray-400">
                <span>{course.duration}</span>
                <Link to="/courses" className="text-royal-blue hover:underline">Learn More</Link>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* 6. Why Choose Us */}
      <section className="py-24 bg-white dark:bg-gray-950 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm mb-4">Excellence</h2>
            <h3 className="text-4xl font-bold text-gray-900 dark:text-white">Why Choose VIP Academy?</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              { title: "Expert Mentors", desc: "Learn from professionals with 10+ years of industry experience.", icon: <Users size={32} /> },
              { title: "Live Projects", desc: "Work on real-world problems and build a strong portfolio.", icon: <BookOpen size={32} /> },
              { title: "Global Network", desc: "Connect with alumni working in top tech companies worldwide.", icon: <Layers size={32} /> }
            ].map((item, i) => (
              <div key={i} className="space-y-4 text-center">
                <div className="mx-auto w-16 h-16 bg-royal-blue text-white rounded-2xl flex items-center justify-center shadow-lg shadow-royal-blue/20">
                  {item.icon}
                </div>
                <h4 className="text-xl font-bold text-gray-900 dark:text-white">{item.title}</h4>
                <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Placement Support */}
      <section className="py-24 bg-deep-blue text-white px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2 space-y-8">
            <h2 className="text-gold font-bold tracking-widest uppercase text-sm">Career Success</h2>
            <h3 className="text-4xl md:text-5xl font-bold leading-tight">100% Placement Support & Career Guidance</h3>
            <p className="text-gray-300 leading-relaxed">
              Our dedicated placement cell works tirelessly to ensure you land your dream job. From resume building to mock interviews, we've got you covered.
            </p>
            <div className="grid grid-cols-2 gap-6">
              <div className="p-6 bg-white/10 rounded-2xl backdrop-blur-sm">
                <h4 className="text-3xl font-bold text-gold mb-2">500+</h4>
                <p className="text-sm text-gray-300">Hiring Partners</p>
              </div>
              <div className="p-6 bg-white/10 rounded-2xl backdrop-blur-sm">
                <h4 className="text-3xl font-bold text-gold mb-2">15 LPA</h4>
                <p className="text-sm text-gray-300">Highest Package</p>
              </div>
            </div>
            <Link to="/placements" className="btn-primary bg-gold text-deep-blue hover:bg-white inline-flex">
              View Placement Reports
            </Link>
          </div>
          <div className="lg:w-1/2 grid grid-cols-3 gap-4 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
            {/* Mock Company Logos */}
            {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(i => (
              <div key={i} className="bg-white/5 p-8 rounded-xl flex items-center justify-center">
                <span className="font-bold text-xl">LOGO</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 11. Stats Counter */}
      <section className="py-20 bg-white dark:bg-gray-950 px-4 sm:px-6 lg:px-8 border-y border-gray-100 dark:border-gray-900">
        <div className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-12">
          {[
            { label: "Students Trained", value: stats.students + "+", icon: <Users className="text-royal-blue" /> },
            { label: "Total Courses", value: stats.courses + "+", icon: <BookOpen className="text-royal-blue" /> },
            { label: "Placements", value: stats.placements + "+", icon: <Award className="text-royal-blue" /> },
            { label: "Live Projects", value: stats.projects + "+", icon: <Briefcase className="text-royal-blue" /> }
          ].map((stat, i) => (
            <div key={i} className="text-center space-y-2">
              <div className="mx-auto w-12 h-12 bg-royal-blue/10 rounded-full flex items-center justify-center mb-4">
                {stat.icon}
              </div>
              <h4 className="text-3xl font-bold text-gray-900 dark:text-white">{stat.value}</h4>
              <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 13. Admission CTA */}
      <section className="py-24 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto bg-royal-blue rounded-3xl p-12 text-center text-white relative overflow-hidden shadow-2xl shadow-royal-blue/30">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
          <div className="relative z-10 space-y-8">
            <h2 className="text-4xl md:text-5xl font-bold">Ready to Start Your Journey?</h2>
            <p className="text-xl text-royal-blue-100 max-w-2xl mx-auto">
              Take the first step towards a rewarding career. Enroll now and get access to premium resources and mentorship.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/signup" className="bg-white text-royal-blue px-8 py-4 rounded-2xl font-bold text-lg hover:bg-gray-100 transition-all">
                Apply Now
              </Link>
              <Link to="/contact" className="bg-royal-blue-700 border border-white/30 px-8 py-4 rounded-2xl font-bold text-lg hover:bg-white/10 transition-all">
                Contact Admissions
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 15. Contact Section */}
      <section className="py-24 bg-white dark:bg-gray-950 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div className="space-y-8">
            <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm">Get In Touch</h2>
            <h3 className="text-4xl font-bold text-gray-900 dark:text-white">Have Questions? We're Here to Help</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Whether you're curious about our courses, placements, or admissions, our team is ready to answer all your questions.
            </p>
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-royal-blue/10 text-royal-blue rounded-xl flex items-center justify-center">
                  <Terminal size={24} />
                </div>
                <div>
                  <p className="font-bold text-gray-900 dark:text-white">Visit Us</p>
                  <p className="text-sm text-gray-500">123 Tech Park, Silicon Valley, Bangalore</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-royal-blue/10 text-royal-blue rounded-xl flex items-center justify-center">
                  <Star size={24} />
                </div>
                <div>
                  <p className="font-bold text-gray-900 dark:text-white">Email Us</p>
                  <p className="text-sm text-gray-500">info@vipacademy.com</p>
                </div>
              </div>
            </div>
          </div>
          <div className="card-premium p-8">
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Full Name</label>
                  <input type="text" className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Email Address</label>
                  <input type="email" className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="john@example.com" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700 dark:text-gray-300">Message</label>
                <textarea rows="4" className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="How can we help you?"></textarea>
              </div>
              <button type="submit" className="btn-primary w-full">Send Message</button>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
