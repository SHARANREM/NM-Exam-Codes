import React, { useState, useEffect } from "react";
import { useParams, useSearchParams, Link } from "react-router-dom";
import { 
  ChevronLeft, 
  Users, 
  Send, 
  Info, 
  Calendar, 
  Clock, 
  MapPin, 
  Briefcase, 
  Award, 
  BookOpen,
  Loader2
} from "lucide-react";
import { doc, getDoc } from "firebase/firestore";
import { db } from "../../firebase/firebaseConfig";
import StudentList from "../../components/admin/StudentList";
import MessageSender from "../../components/admin/MessageSender";
import MessageList from "../../components/admin/MessageList";
import { toast } from "sonner";

const AdminItemDetails = () => {
  const { type, id } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const activeTab = searchParams.get("tab") || "students";
  
  const [item, setItem] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchItem = async () => {
      setLoading(true);
      try {
        const collectionName = type === "course" ? "courses" : type === "internship" ? "internships" : "competitions";
        const docRef = doc(db, collectionName, id);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          setItem({ id: docSnap.id, ...docSnap.data() });
        } else {
          toast.error("Item not found");
        }
      } catch (error) {
        console.error("Error fetching item:", error);
        toast.error("Failed to load item details");
      } finally {
        setLoading(false);
      }
    };

    if (id && type) fetchItem();
  }, [id, type]);

  const handleTabChange = (tab) => {
    setSearchParams({ tab });
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <Loader2 className="animate-spin text-royal-blue mb-4" size={48} />
        <p className="text-gray-500 dark:text-gray-400 font-semibold">Loading details...</p>
      </div>
    );
  }

  if (!item) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Item Not Found</h2>
        <Link to="/admin-dashboard" className="btn-primary inline-flex items-center space-x-2">
          <ChevronLeft size={20} />
          <span>Back to Dashboard</span>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Header */}
      <div className="mb-8">
        <Link 
          to="/admin-dashboard" 
          className="inline-flex items-center space-x-2 text-gray-500 dark:text-gray-400 hover:text-royal-blue transition-colors mb-4"
        >
          <ChevronLeft size={20} />
          <span>Back to Dashboard</span>
        </Link>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-start space-x-4">
            <div className="w-16 h-16 rounded-2xl bg-royal-blue/10 flex items-center justify-center text-royal-blue shrink-0">
              {type === "course" ? <BookOpen size={32} /> : type === "internship" ? <Briefcase size={32} /> : <Award size={32} />}
            </div>
            <div>
              <div className="flex items-center space-x-3 mb-1">
                <span className="px-2 py-0.5 rounded-full bg-royal-blue/10 text-royal-blue text-[10px] font-bold uppercase tracking-wider">
                  {type}
                </span>
                <span className="text-xs text-gray-500 dark:text-gray-400">ID: {item.id}</span>
              </div>
              <h1 className="text-3xl font-extrabold text-gray-900 dark:text-white">{item.title}</h1>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 p-1 bg-gray-100 dark:bg-gray-900 rounded-2xl mb-8 w-fit">
        <button
          onClick={() => handleTabChange("students")}
          className={`flex items-center space-x-2 px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${
            activeTab === "students" 
              ? "bg-white dark:bg-gray-800 text-royal-blue shadow-sm" 
              : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
          }`}
        >
          <Users size={18} />
          <span>Students</span>
        </button>
        <button
          onClick={() => handleTabChange("messages")}
          className={`flex items-center space-x-2 px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${
            activeTab === "messages" 
              ? "bg-white dark:bg-gray-800 text-royal-blue shadow-sm" 
              : "text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
          }`}
        >
          <Send size={18} />
          <span>Messaging</span>
        </button>
      </div>

      {/* Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {activeTab === "students" ? (
            <div className="card-premium p-6">
              <StudentList itemId={item.id} />
            </div>
          ) : (
            <div className="space-y-8">
              <MessageSender itemId={item.id} type={type} />
              <div className="card-premium p-6">
                <MessageList itemId={item.id} isAdmin={true} />
              </div>
            </div>
          )}
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          <div className="card-premium p-6">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4 flex items-center space-x-2">
              <Info size={18} className="text-royal-blue" />
              <span>Item Summary</span>
            </h3>
            
            <div className="space-y-4">
              {item.duration && (
                <div className="flex items-center space-x-3 text-sm text-gray-600 dark:text-gray-400">
                  <Clock size={16} className="text-royal-blue" />
                  <span>Duration: {item.duration}</span>
                </div>
              )}
              {item.mode && (
                <div className="flex items-center space-x-3 text-sm text-gray-600 dark:text-gray-400">
                  <MapPin size={16} className="text-royal-blue" />
                  <span>Mode: {item.mode}</span>
                </div>
              )}
              {item.startDate && (
                <div className="flex items-center space-x-3 text-sm text-gray-600 dark:text-gray-400">
                  <Calendar size={16} className="text-royal-blue" />
                  <span>Starts: {item.startDate}</span>
                </div>
              )}
              <div className="pt-4 border-t border-gray-100 dark:border-gray-800">
                <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                  {item.description}
                </p>
              </div>
            </div>
          </div>
          
          <div className="card-premium p-6 bg-royal-blue/5 border-royal-blue/20">
            <h3 className="text-lg font-bold text-royal-blue mb-2">Quick Tip</h3>
            <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed">
              Messages sent here will trigger real-time updates for all students currently viewing this {type} page.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminItemDetails;
