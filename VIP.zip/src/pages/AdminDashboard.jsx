import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { 
  addCourse, getCourses, updateCourse, deleteCourse,
  addInternship, getInternships, updateInternship, deleteInternship,
  addCompetition, getCompetitions, updateCompetition, deleteCompetition
} from "../services/api";
import { motion } from "motion/react";
import { 
  Plus, 
  Edit2, 
  Trash2, 
  BookOpen, 
  Briefcase, 
  Award, 
  X, 
  Save,
  ChevronRight,
  LayoutDashboard,
  Users,
  Settings
} from "lucide-react";
import { toast } from "sonner";

import AdminItemCard from "../components/admin/AdminItemCard";

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState("courses");
  const [viewMode, setViewMode] = useState("manage"); // 'manage' or 'engage'
  const [items, setItems] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({});

  useEffect(() => {
    let unsubscribe;
    if (activeTab === "courses") unsubscribe = getCourses(setItems);
    else if (activeTab === "internships") unsubscribe = getInternships(setItems);
    else if (activeTab === "competitions") unsubscribe = getCompetitions(setItems);
    return () => unsubscribe && unsubscribe();
  }, [activeTab]);

  const handleOpenModal = (item = null) => {
    setEditingItem(item);
    setFormData(item || {});
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingItem(null);
    setFormData({});
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editingItem) {
        if (activeTab === "courses") await updateCourse(editingItem.id, formData);
        else if (activeTab === "internships") await updateInternship(editingItem.id, formData);
        else if (activeTab === "competitions") await updateCompetition(editingItem.id, formData);
        toast.success("Item updated successfully!");
      } else {
        if (activeTab === "courses") await addCourse(formData);
        else if (activeTab === "internships") await addInternship(formData);
        else if (activeTab === "competitions") await addCompetition(formData);
        toast.success("Item added successfully!");
      }
      handleCloseModal();
    } catch (err) {
      toast.error("Operation failed. Please check your permissions.");
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this item?")) {
      try {
        if (activeTab === "courses") await deleteCourse(id);
        else if (activeTab === "internships") await deleteInternship(id);
        else if (activeTab === "competitions") await deleteCompetition(id);
        toast.success("Item deleted successfully!");
      } catch (err) {
        toast.error("Delete failed.");
      }
    }
  };

  const tabs = [
    { id: "courses", label: "Courses", icon: <BookOpen size={18} /> },
    { id: "internships", label: "Internships", icon: <Briefcase size={18} /> },
    { id: "competitions", label: "Competitions", icon: <Award size={18} /> },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-6">
        <div className="flex space-x-2 p-1 bg-gray-100 dark:bg-gray-800 rounded-2xl w-fit">
          <button
            onClick={() => setViewMode("manage")}
            className={`flex items-center space-x-2 px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${
              viewMode === "manage" 
                ? "bg-white dark:bg-gray-900 text-royal-blue shadow-sm" 
                : "text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
            }`}
          >
            <Settings size={18} />
            <span>Management</span>
          </button>
          <button
            onClick={() => setViewMode("engage")}
            className={`flex items-center space-x-2 px-6 py-2.5 rounded-xl text-sm font-bold transition-all ${
              viewMode === "engage" 
                ? "bg-white dark:bg-gray-900 text-royal-blue shadow-sm" 
                : "text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
            }`}
          >
            <Users size={18} />
            <span>Engagement</span>
          </button>
        </div>
        
        {viewMode === "manage" && (
          <button 
            onClick={() => handleOpenModal()}
            className="btn-primary flex items-center space-x-2"
          >
            <Plus size={20} />
            <span>Add New {activeTab.slice(0, -1)}</span>
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex space-x-2 mb-8 p-1 bg-gray-100 dark:bg-gray-800 rounded-2xl w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center space-x-2 px-6 py-3 rounded-xl text-sm font-bold transition-all ${
              activeTab === tab.id 
                ? "bg-white dark:bg-gray-900 text-royal-blue shadow-sm" 
                : "text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
            }`}
          >
            {tab.icon}
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Content List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {items.map((item) => (
          viewMode === "manage" ? (
            <motion.div
              key={item.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="card-premium overflow-hidden group"
            >
              <div className="h-48 relative">
                <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                <div className="absolute top-4 right-4 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={() => handleOpenModal(item)}
                    className="p-2 bg-white dark:bg-gray-900 text-royal-blue rounded-full shadow-lg hover:scale-110 transition-transform"
                  >
                    <Edit2 size={16} />
                  </button>
                  <button 
                    onClick={() => handleDelete(item.id)}
                    className="p-2 bg-white dark:bg-gray-900 text-red-600 rounded-full shadow-lg hover:scale-110 transition-transform"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              <div className="p-6 space-y-4">
                <h4 className="text-xl font-bold text-gray-900 dark:text-white truncate">{item.title}</h4>
                <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-2">{item.description}</p>
                <div className="pt-4 border-t border-gray-100 dark:border-gray-800 flex justify-between items-center text-xs text-gray-400">
                  <span>{item.duration || item.deadline || "Ongoing"}</span>
                  <span className="font-bold text-royal-blue uppercase">{item.mode || "Global"}</span>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key={item.id}
              layout
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              <AdminItemCard item={item} type={activeTab.slice(0, -1)} />
            </motion.div>
          )
        ))}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="bg-white dark:bg-gray-950 rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl"
          >
            <div className="sticky top-0 bg-white dark:bg-gray-950 p-6 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center z-10">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                {editingItem ? "Edit" : "Add New"} {activeTab.slice(0, -1)}
              </h3>
              <button onClick={handleCloseModal} className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors">
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-8 space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Title</label>
                <input name="title" required value={formData.title || ""} onChange={handleChange} className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="Enter title" />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Description</label>
                <textarea name="description" required rows="4" value={formData.description || ""} onChange={handleChange} className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="Enter description"></textarea>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Image URL</label>
                  <input name="imageUrl" required type="url" value={formData.imageUrl || ""} onChange={handleChange} className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="https://..." />
                </div>
                {activeTab === "courses" && (
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Mode</label>
                    <select name="mode" value={formData.mode || "Online"} onChange={handleChange} className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all">
                      <option value="Online">Online</option>
                      <option value="Offline">Offline</option>
                      <option value="Both">Both</option>
                    </select>
                  </div>
                )}
                {activeTab === "internships" && (
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Apply Link</label>
                    <input name="applyLink" required type="url" value={formData.applyLink || ""} onChange={handleChange} className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="https://..." />
                  </div>
                )}
                {activeTab === "competitions" && (
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Registration Link</label>
                    <input name="registrationLink" required type="url" value={formData.registrationLink || ""} onChange={handleChange} className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="https://..." />
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Duration / Deadline</label>
                  <input name={activeTab === "competitions" ? "deadline" : "duration"} value={formData.duration || formData.deadline || ""} onChange={handleChange} className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="e.g. 6 Months / 2026-12-31" />
                </div>
                {activeTab === "courses" && (
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Google Form Link</label>
                    <input name="googleFormLink" type="url" value={formData.googleFormLink || ""} onChange={handleChange} className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="https://..." />
                  </div>
                )}
              </div>

              <div className="pt-6 flex space-x-4">
                <button type="button" onClick={handleCloseModal} className="btn-secondary flex-1">Cancel</button>
                <button type="submit" className="btn-primary flex-1 flex items-center justify-center space-x-2">
                  <Save size={20} />
                  <span>{editingItem ? "Update" : "Create"}</span>
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
