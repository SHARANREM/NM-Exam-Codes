import React, { useEffect, useState } from "react";
import { getCourses, registerForItem, getUserRegistrations } from "../services/api";
import { useAuth } from "../context/AuthContext";
import CourseCard from "../components/CourseCard";
import { motion } from "motion/react";
import { Search, Filter, BookOpen } from "lucide-react";
import { toast } from "sonner";

const Courses = () => {
  const [courses, setCourses] = useState([]);
  const [registrations, setRegistrations] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filter, setFilter] = useState("All");
  const { user } = useAuth();

  useEffect(() => {
    const unsubCourses = getCourses(setCourses);
    let unsubReg;
    if (user?.uid) {
      unsubReg = getUserRegistrations(user.uid, setRegistrations);
    }
    return () => {
      unsubCourses();
      if (unsubReg) unsubReg();
    };
  }, [user]);

  const handleRegister = async (courseId) => {
    if (!user) {
      toast.error("Please login to register for courses.");
      return;
    }
    try {
      await registerForItem(user.uid, courseId, "course");
      toast.success("Successfully registered for course!");
    } catch (err) {
      toast.error("Registration failed.");
    }
  };

  const filteredCourses = courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filter === "All" || course.mode === filter;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      <div className="text-center mb-16 space-y-4">
        <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm">Explore Programs</h2>
        <h3 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">Our Courses</h3>
        <p className="text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">
          Choose from our wide range of industry-aligned courses and start your journey to professional excellence.
        </p>
      </div>

      {/* Search & Filter */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input 
            type="text" 
            placeholder="Search courses..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all"
          />
        </div>
        <div className="flex items-center space-x-4 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
          <Filter className="text-gray-400 shrink-0" size={20} />
          {["All", "Online", "Offline", "Both"].map((mode) => (
            <button
              key={mode}
              onClick={() => setFilter(mode)}
              className={`px-6 py-2 rounded-xl text-sm font-bold transition-all whitespace-nowrap ${
                filter === mode 
                  ? "bg-royal-blue text-white shadow-lg shadow-royal-blue/20" 
                  : "bg-white dark:bg-gray-900 text-gray-500 hover:text-royal-blue border border-gray-100 dark:border-gray-800"
              }`}
            >
              {mode}
            </button>
          ))}
        </div>
      </div>

      {filteredCourses.length === 0 ? (
        <div className="text-center py-20 card-premium">
          <BookOpen size={48} className="mx-auto text-gray-300 mb-4" />
          <h4 className="text-xl font-bold text-gray-900 dark:text-white">No courses found</h4>
          <p className="text-gray-500">Try adjusting your search or filter.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCourses.map((course) => (
            <CourseCard 
              key={course.id} 
              item={course} 
              type="course" 
              onRegister={handleRegister}
              isRegistered={registrations.some(reg => reg.itemId === course.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default Courses;
