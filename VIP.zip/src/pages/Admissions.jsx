import React from "react";
import { Link } from "react-router-dom";
import { CheckCircle2, ArrowRight, BookOpen, UserCheck, CreditCard, GraduationCap } from "lucide-react";

const Admissions = () => {
  const steps = [
    { title: "Choose Your Course", desc: "Select from our wide range of industry-aligned programs.", icon: <BookOpen size={24} /> },
    { title: "Fill Application", desc: "Complete the online application form with your details.", icon: <UserCheck size={24} /> },
    { title: "Counseling Session", desc: "Talk to our experts to find the best path for your career.", icon: <GraduationCap size={24} /> },
    { title: "Enroll & Start", desc: "Complete the enrollment process and start your journey.", icon: <CreditCard size={24} /> },
  ];

  return (
    <div className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm mb-4">Join Us</h2>
          <h3 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">Admission Process</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-24">
          {steps.map((step, i) => (
            <div key={i} className="relative text-center space-y-4">
              <div className="mx-auto w-16 h-16 bg-royal-blue text-white rounded-2xl flex items-center justify-center shadow-lg shadow-royal-blue/20 relative z-10">
                {step.icon}
              </div>
              <h4 className="text-xl font-bold text-gray-900 dark:text-white">{step.title}</h4>
              <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed">{step.desc}</p>
              {i < steps.length - 1 && (
                <div className="hidden lg:block absolute top-8 left-1/2 w-full h-0.5 bg-royal-blue/10 -z-0"></div>
              )}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <h4 className="text-3xl font-bold text-gray-900 dark:text-white">Why Join VIP Academy?</h4>
            <ul className="space-y-4">
              {[
                "100% Placement Assistance",
                "Industry-Leading Mentors",
                "Hands-on Project Experience",
                "Flexible Learning Modes (Online/Offline)",
                "Global Certification",
                "Lifetime Alumni Support"
              ].map((item, i) => (
                <li key={i} className="flex items-center space-x-3 text-gray-700 dark:text-gray-300">
                  <CheckCircle2 className="text-royal-blue shrink-0" size={20} />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <Link to="/signup" className="btn-primary inline-flex items-center space-x-2">
              <span>Start Your Application</span>
              <ArrowRight size={20} />
            </Link>
          </div>
          <div className="card-premium p-10 bg-royal-blue text-white space-y-6">
            <h4 className="text-2xl font-bold">Download Brochure</h4>
            <p className="text-royal-blue-100">Get detailed information about our courses, fees, and placement reports.</p>
            <form className="space-y-4">
              <input type="text" placeholder="Full Name" className="w-full p-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder:text-white/50 focus:ring-2 focus:ring-white outline-none" />
              <input type="email" placeholder="Email Address" className="w-full p-3 rounded-xl bg-white/10 border border-white/20 text-white placeholder:text-white/50 focus:ring-2 focus:ring-white outline-none" />
              <button className="w-full py-3 bg-white text-royal-blue font-bold rounded-xl hover:bg-gray-100 transition-all">Download Now</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admissions;
