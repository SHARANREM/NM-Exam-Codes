import React from "react";
import { motion } from "motion/react";
import { Award, Briefcase, Users, Star, TrendingUp, CheckCircle2 } from "lucide-react";

const Placements = () => {
  const alumni = [
    { name: "John Doe", role: "Software Engineer", company: "Google", image: "https://picsum.photos/seed/alumni1/100/100" },
    { name: "Jane Smith", role: "Data Scientist", company: "Amazon", image: "https://picsum.photos/seed/alumni2/100/100" },
    { name: "Alex Johnson", role: "Product Manager", company: "Microsoft", image: "https://picsum.photos/seed/alumni3/100/100" },
    { name: "Sarah Williams", role: "Cybersecurity Analyst", company: "IBM", image: "https://picsum.photos/seed/alumni4/100/100" },
  ];

  return (
    <div className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm mb-4">Career Success</h2>
          <h3 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">Placement Support & Reports</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-24">
          {[
            { label: "Placement Rate", value: "100%", icon: <CheckCircle2 size={32} /> },
            { label: "Highest Package", value: "15 LPA", icon: <TrendingUp size={32} /> },
            { label: "Average Package", value: "6.5 LPA", icon: <Star size={32} /> },
          ].map((stat, i) => (
            <div key={i} className="card-premium p-8 text-center space-y-4">
              <div className="mx-auto w-16 h-16 bg-royal-blue/10 text-royal-blue rounded-2xl flex items-center justify-center">
                {stat.icon}
              </div>
              <h4 className="text-4xl font-bold text-gray-900 dark:text-white">{stat.value}</h4>
              <p className="text-sm text-gray-500 dark:text-gray-400 font-bold uppercase tracking-widest">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
          <div className="space-y-8">
            <h4 className="text-3xl font-bold text-gray-900 dark:text-white">Our Placement Ecosystem</h4>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              We don't just teach you how to code; we teach you how to build a career. Our placement cell works with you from day one to ensure you're industry-ready.
            </p>
            <div className="space-y-4">
              {[
                "Resume & Portfolio Building Workshops",
                "Mock Interviews with Industry Experts",
                "Personality Development Sessions",
                "Direct Referrals to Hiring Partners",
                "Lifetime Career Support for Alumni"
              ].map((item, i) => (
                <div key={i} className="flex items-center space-x-3 text-gray-700 dark:text-gray-300">
                  <CheckCircle2 className="text-royal-blue shrink-0" size={20} />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <img src="https://picsum.photos/seed/placement/800/600" alt="Placement Support" className="rounded-3xl shadow-2xl" referrerPolicy="no-referrer" />
          </div>
        </div>

        <h4 className="text-3xl font-bold text-gray-900 dark:text-white text-center mb-12">Success Stories</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {alumni.map((person, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -10 }}
              className="card-premium p-8 text-center space-y-4"
            >
              <img src={person.image} alt={person.name} className="w-20 h-20 rounded-full mx-auto border-4 border-royal-blue/10" referrerPolicy="no-referrer" />
              <h5 className="text-lg font-bold text-gray-900 dark:text-white">{person.name}</h5>
              <p className="text-sm text-gray-500 dark:text-gray-400">{person.role}</p>
              <div className="pt-4 border-t border-gray-100 dark:border-gray-800">
                <p className="text-xs font-bold text-royal-blue uppercase tracking-widest">{person.company}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Placements;
