import React from "react";
import { Mail, Phone, MapPin, Send, MessageSquare, Clock } from "lucide-react";

const Contact = () => {
  return (
    <div className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm mb-4">Get In Touch</h2>
          <h3 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">Contact Us</h3>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mb-24">
          {[
            { label: "Email Us", value: "info@vipacademy.com", icon: <Mail size={32} /> },
            { label: "Call Us", value: "+91 1234567890", icon: <Phone size={32} /> },
            { label: "Visit Us", value: "123 Tech Park, Bangalore", icon: <MapPin size={32} /> },
          ].map((item, i) => (
            <div key={i} className="card-premium p-8 text-center space-y-4">
              <div className="mx-auto w-16 h-16 bg-royal-blue/10 text-royal-blue rounded-2xl flex items-center justify-center">
                {item.icon}
              </div>
              <h4 className="text-xl font-bold text-gray-900 dark:text-white">{item.label}</h4>
              <p className="text-sm text-gray-500 dark:text-gray-400 font-bold uppercase tracking-widest">{item.value}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="space-y-8">
            <h4 className="text-3xl font-bold text-gray-900 dark:text-white">Send Us a Message</h4>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              Have a question or need more information? Fill out the form below and our team will get back to you as soon as possible.
            </p>
            <div className="space-y-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-royal-blue/10 text-royal-blue rounded-xl flex items-center justify-center">
                  <MessageSquare size={24} />
                </div>
                <div>
                  <p className="font-bold text-gray-900 dark:text-white">Live Chat</p>
                  <p className="text-sm text-gray-500">Available Mon-Fri, 9am-6pm</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-royal-blue/10 text-royal-blue rounded-xl flex items-center justify-center">
                  <Clock size={24} />
                </div>
                <div>
                  <p className="font-bold text-gray-900 dark:text-white">Response Time</p>
                  <p className="text-sm text-gray-500">Usually within 24 hours</p>
                </div>
              </div>
            </div>
          </div>
          <div className="card-premium p-10">
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Full Name</label>
                  <input type="text" className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Email Address</label>
                  <input type="email" className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="john@example.com" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Subject</label>
                <input type="text" className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="How can we help?" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Message</label>
                <textarea rows="4" className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-800 bg-gray-50 dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all" placeholder="Your message..."></textarea>
              </div>
              <button type="submit" className="btn-primary w-full flex items-center justify-center space-x-2">
                <Send size={20} />
                <span>Send Message</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
