import React from "react";
import { motion } from "motion/react";
import { CheckCircle2, Award, Users, Globe } from "lucide-react";

const About = () => {
  return (
    <div className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm mb-4">Our Story</h2>
          <h3 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">About VIP Academy</h3>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
          <div className="space-y-6">
            <h4 className="text-3xl font-bold text-gray-900 dark:text-white">Pioneering Tech Education Since 2015</h4>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              VIP Academy was founded with a single mission: to provide high-quality, accessible, and industry-relevant tech education to students across the globe. We believe that everyone should have the opportunity to build a successful career in technology.
            </p>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              Over the years, we have grown from a small training center to a global educational platform, serving thousands of students and partnering with top tech companies.
            </p>
            <div className="grid grid-cols-2 gap-6 pt-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-royal-blue/10 rounded-lg text-royal-blue">
                  <Users size={24} />
                </div>
                <div>
                  <p className="font-bold text-gray-900 dark:text-white">10,000+</p>
                  <p className="text-xs text-gray-500 uppercase">Alumni</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-royal-blue/10 rounded-lg text-royal-blue">
                  <Globe size={24} />
                </div>
                <div>
                  <p className="font-bold text-gray-900 dark:text-white">20+</p>
                  <p className="text-xs text-gray-500 uppercase">Countries</p>
                </div>
              </div>
            </div>
          </div>
          <div className="relative">
            <img src="https://picsum.photos/seed/about2/800/600" alt="About VIP" className="rounded-3xl shadow-2xl" referrerPolicy="no-referrer" />
          </div>
        </div>

        <div className="bg-deep-blue rounded-3xl p-12 text-white">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <div className="space-y-4">
              <div className="mx-auto w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center">
                <Award className="text-gold" size={32} />
              </div>
              <h5 className="text-xl font-bold">Our Mission</h5>
              <p className="text-gray-300 text-sm">To empower individuals with the skills needed to thrive in the digital economy.</p>
            </div>
            <div className="space-y-4">
              <div className="mx-auto w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center">
                <CheckCircle2 className="text-gold" size={32} />
              </div>
              <h5 className="text-xl font-bold">Our Vision</h5>
              <p className="text-gray-300 text-sm">To be the world's most trusted partner for career transformation in tech.</p>
            </div>
            <div className="space-y-4">
              <div className="mx-auto w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center">
                <Users className="text-gold" size={32} />
              </div>
              <h5 className="text-xl font-bold">Our Values</h5>
              <p className="text-gray-300 text-sm">Integrity, Innovation, and Student-First approach in everything we do.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
