import React from "react";
import { Award, CheckCircle2, Globe, Shield, Star, BookOpen } from "lucide-react";

const Certifications = () => {
  const certifications = [
    { title: "AI & Machine Learning Specialist", icon: <Award size={32} />, desc: "Recognized by top tech firms for advanced AI skills." },
    { title: "Full Stack Web Developer", icon: <Globe size={32} />, desc: "Validate your ability to build complex web applications." },
    { title: "Data Science Professional", icon: <Star size={32} />, desc: "Certified expertise in data analysis and visualization." },
    { title: "Cybersecurity Expert", icon: <Shield size={32} />, desc: "Industry-standard certification for security professionals." },
  ];

  return (
    <div className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm mb-4">Validate Your Skills</h2>
          <h3 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">Global Certifications</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
          {certifications.map((cert, i) => (
            <div key={i} className="card-premium p-8 text-center space-y-4">
              <div className="mx-auto w-16 h-16 bg-royal-blue/10 text-royal-blue rounded-2xl flex items-center justify-center">
                {cert.icon}
              </div>
              <h4 className="text-xl font-bold text-gray-900 dark:text-white">{cert.title}</h4>
              <p className="text-sm text-gray-500 dark:text-gray-400 leading-relaxed">{cert.desc}</p>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <img src="https://picsum.photos/seed/cert/800/600" alt="Certification" className="rounded-3xl shadow-2xl" referrerPolicy="no-referrer" />
          </div>
          <div className="space-y-8">
            <h4 className="text-3xl font-bold text-gray-900 dark:text-white">Why Our Certifications Matter?</h4>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              Our certifications are recognized by leading tech companies worldwide. They validate your skills and demonstrate your commitment to professional excellence.
            </p>
            <div className="space-y-4">
              {[
                "Industry-Recognized Standards",
                "Verifiable Digital Credentials",
                "Global Acceptance by Top Employers",
                "Hands-on Assessment Based",
                "Lifetime Validity"
              ].map((item, i) => (
                <div key={i} className="flex items-center space-x-3 text-gray-700 dark:text-gray-300">
                  <CheckCircle2 className="text-royal-blue shrink-0" size={20} />
                  <span>{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Certifications;
