import React from "react";
import { motion } from "motion/react";
import { Calendar, User, ArrowRight } from "lucide-react";

const Blog = () => {
  const posts = [
    { title: "The Future of AI in 2026", desc: "Exploring the latest trends and innovations in artificial intelligence.", date: "March 20, 2026", author: "Dr. Sarah Lee", image: "https://picsum.photos/seed/blog1/800/600" },
    { title: "Mastering Full Stack Development", desc: "A comprehensive guide to becoming a successful full stack developer.", date: "March 15, 2026", author: "John Doe", image: "https://picsum.photos/seed/blog2/800/600" },
    { title: "Cybersecurity Best Practices", desc: "Protect your digital assets with these essential security tips.", date: "March 10, 2026", author: "Alex Johnson", image: "https://picsum.photos/seed/blog3/800/600" },
    { title: "Data Science for Beginners", desc: "Start your journey into the world of data analysis and visualization.", date: "March 5, 2026", author: "Jane Smith", image: "https://picsum.photos/seed/blog4/800/600" },
  ];

  return (
    <div className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm mb-4">Latest Insights</h2>
          <h3 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">Our Blog</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {posts.map((post, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -10 }}
              className="card-premium overflow-hidden group"
            >
              <div className="h-64 relative overflow-hidden">
                <img src={post.image} alt={post.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" referrerPolicy="no-referrer" />
              </div>
              <div className="p-8 space-y-4">
                <div className="flex items-center space-x-4 text-xs text-gray-400 font-bold uppercase tracking-widest">
                  <div className="flex items-center space-x-1">
                    <Calendar size={14} />
                    <span>{post.date}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <User size={14} />
                    <span>{post.author}</span>
                  </div>
                </div>
                <h4 className="text-2xl font-bold text-gray-900 dark:text-white group-hover:text-royal-blue transition-colors">{post.title}</h4>
                <p className="text-gray-500 dark:text-gray-400 leading-relaxed">{post.desc}</p>
                <button className="text-royal-blue font-bold flex items-center space-x-2 hover:underline">
                  <span>Read More</span>
                  <ArrowRight size={18} />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Blog;
