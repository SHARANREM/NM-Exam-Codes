import React, { useEffect, useState } from "react";
import { getInternships, registerForItem, getUserRegistrations } from "../services/api";
import { useAuth } from "../context/AuthContext";
import CourseCard from "../components/CourseCard";
import { motion } from "motion/react";
import { Search, Briefcase } from "lucide-react";
import { toast } from "sonner";

const Internships = () => {
  const [internships, setInternships] = useState([]);
  const [registrations, setRegistrations] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const { user } = useAuth();

  useEffect(() => {
    const unsubInternships = getInternships(setInternships);
    let unsubReg;
    if (user?.uid) {
      unsubReg = getUserRegistrations(user.uid, setRegistrations);
    }
    return () => {
      unsubInternships();
      if (unsubReg) unsubReg();
    };
  }, [user]);

  const handleRegister = async (id) => {
    if (!user) {
      toast.error("Please login to register for internships.");
      return;
    }
    try {
      await registerForItem(user.uid, id, "internship");
      toast.success("Successfully registered for internship!");
    } catch (err) {
      toast.error("Registration failed.");
    }
  };

  const filteredInternships = internships.filter(item => 
    item.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
      <div className="text-center mb-16 space-y-4">
        <h2 className="text-royal-blue font-bold tracking-widest uppercase text-sm">Career Opportunities</h2>
        <h3 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white">Internships & Live Projects</h3>
        <p className="text-gray-500 dark:text-gray-400 max-w-2xl mx-auto">
          Gain hands-on experience by working on real-world projects with our industry partners.
        </p>
      </div>

      {/* Search */}
      <div className="flex justify-center mb-12">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
          <input 
            type="text" 
            placeholder="Search internships..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all"
          />
        </div>
      </div>

      {filteredInternships.length === 0 ? (
        <div className="text-center py-20 card-premium">
          <Briefcase size={48} className="mx-auto text-gray-300 mb-4" />
          <h4 className="text-xl font-bold text-gray-900 dark:text-white">No internships found</h4>
          <p className="text-gray-500">Try adjusting your search.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredInternships.map((item) => (
            <CourseCard 
              key={item.id} 
              item={item} 
              type="internship" 
              onRegister={handleRegister}
              isRegistered={registrations.some(reg => reg.itemId === item.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default Internships;
