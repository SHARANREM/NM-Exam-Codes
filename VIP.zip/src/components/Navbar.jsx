import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Menu, X, User, LogOut, LayoutDashboard } from "lucide-react";
import ThemeToggle from "./ThemeToggle";
import { useAuth } from "../context/AuthContext";
import { auth } from "../firebase/firebaseConfig";
import { signOut } from "firebase/auth";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { user, userData, isAdmin } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut(auth);
    navigate("/");
  };

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "Courses", path: "/courses" },
    { name: "Admissions", path: "/admissions" },
    { name: "Placements", path: "/placements" },
    { name: "Certifications", path: "/certifications" },
    { name: "Internships", path: "/internships" },
    { name: "Blog", path: "/blog" },
    { name: "Contact", path: "/contact" },
  ];

  return (
    <nav className="sticky top-0 z-40 w-full glass shadow-sm">
      {/* Top Info Bar */}
      <div className="hidden md:block bg-deep-blue text-white text-xs py-1 px-4">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <span>Welcome to VIP Academy - Build Your Future Today</span>
          <div className="flex gap-4">
            <span>📞 +91 1234567890</span>
            <span>✉️ info@vipacademy.com</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <Link to="/" className="flex items-center">
            <span className="text-2xl font-bold text-royal-blue">VIP</span>
            <span className="text-2xl font-light text-gray-800 dark:text-gray-200 ml-1">Academy</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden lg:flex items-center space-x-6">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className="text-sm font-medium text-gray-600 dark:text-gray-300 hover:text-royal-blue dark:hover:text-royal-blue transition-colors"
              >
                {link.name}
              </Link>
            ))}
          </div>

          <div className="hidden lg:flex items-center space-x-4">
            <ThemeToggle />
            {user ? (
              <div className="flex items-center space-x-4">
                <Link
                  to={isAdmin ? "/admin-dashboard" : "/dashboard"}
                  className="p-2 rounded-full bg-gray-100 dark:bg-gray-800 text-royal-blue"
                  title="Dashboard"
                >
                  <LayoutDashboard size={20} />
                </Link>
                <button
                  onClick={handleLogout}
                  className="p-2 rounded-full bg-red-50 dark:bg-red-900/20 text-red-600"
                  title="Logout"
                >
                  <LogOut size={20} />
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <Link to="/login" className="text-sm font-medium text-gray-600 dark:text-gray-300 hover:text-royal-blue">
                  Login
                </Link>
                <Link to="/signup" className="btn-primary py-2 px-4 text-sm">
                  Apply Now
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center space-x-4">
            <ThemeToggle />
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-600 dark:text-gray-300"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden bg-white dark:bg-gray-950 border-t border-gray-100 dark:border-gray-800 py-4 px-4 space-y-2">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              onClick={() => setIsOpen(false)}
              className="block py-2 text-base font-medium text-gray-600 dark:text-gray-300 hover:text-royal-blue"
            >
              {link.name}
            </Link>
          ))}
          <div className="pt-4 flex flex-col space-y-3">
            {user ? (
              <>
                <Link
                  to={isAdmin ? "/admin-dashboard" : "/dashboard"}
                  onClick={() => setIsOpen(false)}
                  className="btn-secondary text-center"
                >
                  Dashboard
                </Link>
                <button
                  onClick={handleLogout}
                  className="btn-primary bg-red-600 hover:bg-red-700"
                >
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  onClick={() => setIsOpen(false)}
                  className="btn-secondary text-center"
                >
                  Login
                </Link>
                <Link
                  to="/signup"
                  onClick={() => setIsOpen(false)}
                  className="btn-primary text-center"
                >
                  Apply Now
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
