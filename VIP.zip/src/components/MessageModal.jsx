import React from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Bell } from "lucide-react";
import MessageList from "./admin/MessageList";

const MessageModal = ({ isOpen, onClose, itemId, itemTitle }) => {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white dark:bg-gray-950 rounded-3xl w-full max-w-lg max-h-[80vh] overflow-hidden shadow-2xl border border-gray-100 dark:border-gray-800"
        >
          <div className="p-6 border-b border-gray-100 dark:border-gray-800 flex justify-between items-center bg-royal-blue/5">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-xl bg-royal-blue/10 flex items-center justify-center text-royal-blue">
                <Bell size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">Announcements</h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 truncate max-w-[200px]">{itemTitle}</p>
              </div>
            </div>
            <button 
              onClick={onClose} 
              className="p-2 hover:bg-gray-200 dark:hover:bg-gray-800 rounded-full transition-colors text-gray-500"
            >
              <X size={20} />
            </button>
          </div>

          <div className="p-6 overflow-y-auto max-h-[60vh]">
            <MessageList itemId={itemId} isAdmin={false} />
          </div>
          
          <div className="p-4 bg-gray-50 dark:bg-gray-900/50 border-t border-gray-100 dark:border-gray-800 text-center">
            <p className="text-[10px] text-gray-400 uppercase tracking-widest font-bold">VIP Academy Engagement System</p>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default MessageModal;
