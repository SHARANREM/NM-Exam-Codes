import React from "react";
import { Link } from "react-router-dom";
import { Facebook, Twitter, Linkedin, Instagram, Mail, Phone, MapPin } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-white dark:bg-gray-950 border-t border-gray-100 dark:border-gray-900 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Section */}
          <div className="space-y-6">
            <Link to="/" className="flex items-center">
              <span className="text-3xl font-bold text-royal-blue">VIP</span>
              <span className="text-3xl font-light text-gray-800 dark:text-gray-200 ml-1">Academy</span>
            </Link>
            <p className="text-gray-500 dark:text-gray-400 text-sm leading-relaxed">
              Empowering the next generation of tech leaders through industry-aligned education, hands-on projects, and career support.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="p-2 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-royal-blue hover:text-white transition-all">
                <Facebook size={18} />
              </a>
              <a href="#" className="p-2 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-royal-blue hover:text-white transition-all">
                <Twitter size={18} />
              </a>
              <a href="#" className="p-2 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-royal-blue hover:text-white transition-all">
                <Linkedin size={18} />
              </a>
              <a href="#" className="p-2 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-royal-blue hover:text-white transition-all">
                <Instagram size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">Quick Links</h3>
            <ul className="space-y-4">
              {["About Us", "Courses", "Admissions", "Placements", "Internships", "Contact"].map((item) => (
                <li key={item}>
                  <Link to={`/${item.toLowerCase().replace(" ", "-")}`} className="text-gray-500 dark:text-gray-400 hover:text-royal-blue transition-colors text-sm">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Courses */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">Popular Courses</h3>
            <ul className="space-y-4">
              {["AI & Machine Learning", "Data Science", "Full Stack Development", "Python Programming", "Cybersecurity", "Cloud Computing"].map((item) => (
                <li key={item}>
                  <Link to="/courses" className="text-gray-500 dark:text-gray-400 hover:text-royal-blue transition-colors text-sm">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-6">Contact Us</h3>
            <ul className="space-y-4">
              <li className="flex items-start space-x-3 text-sm text-gray-500 dark:text-gray-400">
                <MapPin size={18} className="text-royal-blue shrink-0" />
                <span>123 Tech Park, Silicon Valley, Bangalore, India - 560001</span>
              </li>
              <li className="flex items-center space-x-3 text-sm text-gray-500 dark:text-gray-400">
                <Phone size={18} className="text-royal-blue shrink-0" />
                <span>+91 1234567890</span>
              </li>
              <li className="flex items-center space-x-3 text-sm text-gray-500 dark:text-gray-400">
                <Mail size={18} className="text-royal-blue shrink-0" />
                <span>info@vipacademy.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-gray-100 dark:border-gray-900 flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-gray-500 dark:text-gray-400 text-sm">
            © {new Date().getFullYear()} VIP Academy. All rights reserved.
          </p>
          <div className="flex space-x-6 text-sm text-gray-500 dark:text-gray-400">
            <a href="#" className="hover:text-royal-blue transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-royal-blue transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
