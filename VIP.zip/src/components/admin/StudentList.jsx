import React, { useState, useEffect } from "react";
import { 
  Search, 
  Mail, 
  Phone, 
  FileText, 
  Linkedin, 
  Github, 
  Copy, 
  ExternalLink,
  User,
  Loader2
} from "lucide-react";
import { collection, query, where, getDocs, doc, getDoc } from "firebase/firestore";
import { db } from "../../firebase/firebaseConfig";
import { toast } from "sonner";

const StudentList = ({ itemId }) => {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const fetchStudents = async () => {
      setLoading(true);
      try {
        // 1. Fetch registrations for this itemId
        const registrationsRef = collection(db, "registrations");
        const q = query(registrationsRef, where("itemId", "==", itemId));
        const querySnapshot = await getDocs(q);
        
        const userIds = querySnapshot.docs.map(doc => doc.data().userId);
        
        if (userIds.length === 0) {
          setStudents([]);
          setLoading(false);
          return;
        }

        // 2. Fetch user details for each userId
        const studentDetails = await Promise.all(
          userIds.map(async (uid) => {
            const userDoc = await getDoc(doc(db, "users", uid));
            return userDoc.exists() ? { id: uid, ...userDoc.data() } : null;
          })
        );

        setStudents(studentDetails.filter(s => s !== null));
      } catch (error) {
        console.error("Error fetching students:", error);
        toast.error("Failed to load students");
      } finally {
        setLoading(false);
      }
    };

    if (itemId) fetchStudents();
  }, [itemId]);

  const filteredStudents = students.filter(student => 
    student.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    student.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const copyEmail = (email) => {
    navigator.clipboard.writeText(email);
    toast.success("Email copied to clipboard");
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <Loader2 className="animate-spin text-royal-blue mb-4" size={40} />
        <p className="text-gray-500 dark:text-gray-400">Loading student list...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="relative w-full sm:w-96">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
          <input
            type="text"
            placeholder="Search by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all"
          />
        </div>
        
        <div className="px-4 py-2 rounded-full bg-royal-blue/10 text-royal-blue font-bold text-sm">
          {filteredStudents.length} Students Enrolled
        </div>
      </div>

      {filteredStudents.length === 0 ? (
        <div className="text-center py-20 bg-gray-50 dark:bg-gray-900/50 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800">
          <User className="mx-auto text-gray-300 dark:text-gray-700 mb-4" size={48} />
          <p className="text-gray-500 dark:text-gray-400">No students found matching your search.</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-gray-100 dark:border-gray-800">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 dark:bg-gray-900">
                <th className="px-6 py-4 text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Student</th>
                <th className="px-6 py-4 text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider">Contact</th>
                <th className="px-6 py-4 text-sm font-bold text-gray-700 dark:text-gray-300 uppercase tracking-wider text-center">Links</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
              {filteredStudents.map((student) => (
                <tr key={student.id} className="hover:bg-gray-50/50 dark:hover:bg-gray-900/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-full bg-royal-blue/10 flex items-center justify-center text-royal-blue font-bold">
                        {student.name?.charAt(0).toUpperCase() || "S"}
                      </div>
                      <div>
                        <div className="font-bold text-gray-900 dark:text-white">{student.name}</div>
                        <div className="text-xs text-gray-500 dark:text-gray-400">ID: {student.id.slice(0, 8)}...</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                        <Mail size={14} />
                        <span>{student.email}</span>
                        <button 
                          onClick={() => copyEmail(student.email)}
                          className="p-1 hover:bg-gray-200 dark:hover:bg-gray-800 rounded transition-colors"
                        >
                          <Copy size={12} />
                        </button>
                      </div>
                      {student.mobile && (
                        <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                          <Phone size={14} />
                          <span>{student.mobile}</span>
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-center space-x-3">
                      {student.resumeUrl && (
                        <a 
                          href={student.resumeUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:text-royal-blue transition-colors"
                          title="Resume"
                        >
                          <FileText size={18} />
                        </a>
                      )}
                      {student.linkedinUrl && (
                        <a 
                          href={student.linkedinUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:text-royal-blue transition-colors"
                          title="LinkedIn"
                        >
                          <Linkedin size={18} />
                        </a>
                      )}
                      {student.githubUrl && (
                        <a 
                          href={student.githubUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-2 rounded-lg bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:text-royal-blue transition-colors"
                          title="GitHub"
                        >
                          <Github size={18} />
                        </a>
                      )}
                      {!student.resumeUrl && !student.linkedinUrl && !student.githubUrl && (
                        <span className="text-xs text-gray-400 italic">No links provided</span>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default StudentList;
