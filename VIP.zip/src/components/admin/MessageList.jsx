import React, { useState, useEffect } from "react";
import { 
  MessageSquare, 
  Clock, 
  Trash2, 
  Loader2, 
  Bell,
  Calendar
} from "lucide-react";
import { collection, query, where, orderBy, onSnapshot, deleteDoc, doc } from "firebase/firestore";
import { db } from "../../firebase/firebaseConfig";
import { toast } from "sonner";
import { format } from "date-fns";

const MessageList = ({ itemId, isAdmin = false }) => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const messagesRef = collection(db, "messages");
    const q = query(
      messagesRef, 
      where("itemId", "==", itemId),
      orderBy("createdAt", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const messagesData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setMessages(messagesData);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching messages:", error);
      toast.error("Failed to load announcements");
      setLoading(false);
    });

    return () => unsubscribe();
  }, [itemId]);

  const handleDelete = async (messageId) => {
    if (!window.confirm("Are you sure you want to delete this message?")) return;
    
    try {
      await deleteDoc(doc(db, "messages", messageId));
      toast.success("Message deleted");
    } catch (error) {
      console.error("Error deleting message:", error);
      toast.error("Failed to delete message");
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-10">
        <Loader2 className="animate-spin text-royal-blue mb-2" size={30} />
        <p className="text-sm text-gray-500 dark:text-gray-400">Loading announcements...</p>
      </div>
    );
  }

  if (messages.length === 0) {
    return (
      <div className="text-center py-10 bg-gray-50 dark:bg-gray-900/50 rounded-2xl border border-dashed border-gray-200 dark:border-gray-800">
        <MessageSquare className="mx-auto text-gray-300 dark:text-gray-700 mb-2" size={32} />
        <p className="text-sm text-gray-500 dark:text-gray-400">No announcements yet.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 mb-2 text-gray-900 dark:text-white font-bold">
        <Bell size={18} className="text-royal-blue" />
        <h3>{isAdmin ? "Message History" : "Admin Announcements"}</h3>
      </div>
      
      <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className="p-4 rounded-2xl bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-800 shadow-sm hover:shadow-md transition-shadow relative group"
          >
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center space-x-2 text-xs text-royal-blue font-semibold">
                <Calendar size={12} />
                <span>{format(new Date(msg.createdAt), "MMM dd, yyyy • hh:mm a")}</span>
              </div>
              
              {isAdmin && (
                <button 
                  onClick={() => handleDelete(msg.id)}
                  className="p-1.5 rounded-lg bg-red-50 dark:bg-red-900/20 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-100 dark:hover:bg-red-900/40"
                  title="Delete message"
                >
                  <Trash2 size={14} />
                </button>
              )}
            </div>
            
            <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed whitespace-pre-wrap">
              {msg.message}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MessageList;
