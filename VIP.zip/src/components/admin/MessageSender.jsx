import React, { useState } from "react";
import { Send, Loader2, AlertCircle } from "lucide-react";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { db } from "../../firebase/firebaseConfig";
import { useAuth } from "../../context/AuthContext";
import { toast } from "sonner";

const MessageSender = ({ itemId, type }) => {
  const { user } = useAuth();
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!message.trim()) return;

    setSending(true);
    try {
      const messagesRef = collection(db, "messages");
      await addDoc(messagesRef, {
        itemId,
        type,
        message: message.trim(),
        createdAt: new Date().toISOString(), // Use ISO string for consistency with blueprint
        createdBy: user.uid
      });

      setMessage("");
      toast.success("Message sent to all students!");
    } catch (error) {
      console.error("Error sending message:", error);
      toast.error("Failed to send message");
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="card-premium p-6">
      <div className="flex items-center space-x-2 mb-4 text-royal-blue">
        <Send size={20} />
        <h3 className="text-lg font-bold">Send Announcement</h3>
      </div>
      
      <form onSubmit={handleSendMessage} className="space-y-4">
        <div className="relative">
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Write your message here... (e.g., Class rescheduled, New materials uploaded)"
            className="w-full h-32 px-4 py-3 rounded-2xl border border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 focus:ring-2 focus:ring-royal-blue outline-none transition-all resize-none text-gray-700 dark:text-gray-300"
            required
          />
          <div className="absolute bottom-3 right-3 text-xs text-gray-400">
            {message.length} characters
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs text-gray-500 dark:text-gray-400">
            <AlertCircle size={14} />
            <span>This will be visible to all enrolled students instantly.</span>
          </div>
          
          <button
            type="submit"
            disabled={sending || !message.trim()}
            className="flex items-center space-x-2 px-6 py-2 rounded-xl bg-royal-blue text-white font-bold hover:bg-deep-blue transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-royal-blue/20"
          >
            {sending ? (
              <>
                <Loader2 className="animate-spin" size={18} />
                <span>Sending...</span>
              </>
            ) : (
              <>
                <Send size={18} />
                <span>Send to All</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};

export default MessageSender;
