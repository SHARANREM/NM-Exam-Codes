import React from "react";
import { Users, Send, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

const AdminItemCard = ({ item, type }) => {
  return (
    <div className="card-premium p-6 flex flex-col h-full">
      <div className="flex justify-between items-start mb-4">
        <span className="px-3 py-1 rounded-full bg-royal-blue/10 text-royal-blue text-xs font-bold uppercase tracking-wider">
          {type}
        </span>
      </div>
      
      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2 line-clamp-1">
        {item.title}
      </h3>
      
      <p className="text-gray-600 dark:text-gray-400 text-sm mb-6 line-clamp-2 flex-grow">
        {item.description}
      </p>
      
      <div className="grid grid-cols-2 gap-3">
        <Link 
          to={`/admin-dashboard/details/${type}/${item.id}`}
          className="flex items-center justify-center space-x-2 px-4 py-2 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 font-semibold hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors text-sm"
        >
          <Users size={16} />
          <span>Students</span>
        </Link>
        
        <Link 
          to={`/admin-dashboard/details/${type}/${item.id}?tab=messages`}
          className="flex items-center justify-center space-x-2 px-4 py-2 rounded-xl bg-royal-blue text-white font-semibold hover:bg-deep-blue transition-colors text-sm shadow-md shadow-royal-blue/20"
        >
          <Send size={16} />
          <span>Message</span>
        </Link>
      </div>
    </div>
  );
};

export default AdminItemCard;
