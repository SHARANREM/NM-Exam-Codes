import React from "react";
import { motion } from "motion/react";

const Loader = () => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-white dark:bg-gray-950">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{
          duration: 0.8,
          repeat: Infinity,
          repeatType: "reverse",
        }}
        className="flex flex-col items-center"
      >
        <div className="w-16 h-16 border-4 border-royal-blue border-t-transparent rounded-full animate-spin"></div>
        <h1 className="mt-4 text-2xl font-bold text-royal-blue">VIP Academy</h1>
      </motion.div>
    </div>
  );
};

export default Loader;
