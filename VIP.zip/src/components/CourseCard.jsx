import React, { useState } from "react";
import { motion } from "motion/react";
import { Clock, MapPin, ArrowRight, ExternalLink, Bell } from "lucide-react";
import MessageModal from "./MessageModal";

const CourseCard = ({ item, type, onRegister, isRegistered }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <motion.div
        whileHover={{ y: -10 }}
        className="card-premium overflow-hidden flex flex-col h-full group"
      >
        <div className="h-48 relative overflow-hidden">
          <img 
            src={item.imageUrl} 
            alt={item.title} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
            referrerPolicy="no-referrer"
          />
          <div className="absolute top-4 right-4 px-3 py-1 bg-white/90 dark:bg-black/90 backdrop-blur-sm rounded-full text-[10px] font-bold uppercase tracking-wider text-royal-blue">
            {item.mode || item.stipend || "Open"}
          </div>
          
          {isRegistered && (
            <button 
              onClick={() => setIsModalOpen(true)}
              className="absolute bottom-4 right-4 p-2 bg-royal-blue text-white rounded-full shadow-lg hover:scale-110 transition-transform z-10"
              title="View Announcements"
            >
              <Bell size={18} />
            </button>
          )}
        </div>
        
        <div className="p-6 flex-grow flex flex-col space-y-4">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white line-clamp-1">{item.title}</h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-3 leading-relaxed">
            {item.description}
          </p>
          
          <div className="pt-4 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between text-xs text-gray-400 font-medium">
            <div className="flex items-center space-x-1">
              <Clock size={14} />
              <span>{item.duration || item.deadline}</span>
            </div>
            {item.requirements && (
              <div className="flex items-center space-x-1">
                <MapPin size={14} />
                <span className="truncate max-w-[80px]">{item.requirements}</span>
              </div>
            )}
          </div>

          <div className="pt-4 mt-auto flex space-x-2">
            {isRegistered ? (
              <button 
                onClick={() => setIsModalOpen(true)}
                className="btn-secondary w-full text-sm py-2 flex items-center justify-center space-x-2"
              >
                <Bell size={16} />
                <span>Announcements</span>
              </button>
            ) : (
              <button 
                onClick={() => onRegister(item.id)}
                className="btn-primary w-full text-sm py-2"
              >
                Register Now
              </button>
            )}
            {(item.googleFormLink || item.applyLink || item.registrationLink) && (
              <a 
                href={item.googleFormLink || item.applyLink || item.registrationLink} 
                target="_blank" 
                rel="noopener noreferrer"
                className="p-2 rounded-xl bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-royal-blue hover:text-white transition-all"
              >
                <ExternalLink size={20} />
              </a>
            )}
          </div>
        </div>
      </motion.div>

      <MessageModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        itemId={item.id} 
        itemTitle={item.title} 
        type={type}
      />
    </>
  );
};

export default CourseCard;
